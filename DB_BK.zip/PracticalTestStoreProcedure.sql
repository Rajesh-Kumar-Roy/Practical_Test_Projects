  
CREATE PROCEDURE [dbo].[SaveSaleWithCustomer]
    @CustomerId INT = NULL,             
    @CustomerName NVARCHAR(100) = NULL,  
    @CustomerEmail NVARCHAR(100) = NULL, 
    @CustomerPhone NVARCHAR(20) = NULL,  
    @CustomerAddress NVARCHAR(200) = NULL, 
    @SaleDate DATETIME,
    @SaleItems AS SaleItemType READONLY, 
    @NewSaleId INT OUTPUT,               
    @NewCustomerId INT OUTPUT            
AS
BEGIN
   
    BEGIN TRANSACTION;

    BEGIN TRY
       
        IF @CustomerId IS NULL
        BEGIN
            
            INSERT INTO Customer (Name, Email, Phone, Address)
            VALUES (@CustomerName, @CustomerEmail, @CustomerPhone, @CustomerAddress);

            
            SET @NewCustomerId = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
          
            SET @NewCustomerId = @CustomerId;
        END

        
        INSERT INTO Sale (SaleDate, CustomerId)
        VALUES (@SaleDate, @NewCustomerId);

    
        SET @NewSaleId = SCOPE_IDENTITY();

        
        INSERT INTO SaleItem (SaleId, ProductId, Quantity, TotalPrice)
        SELECT @NewSaleId, ProductId, Quantity, TotalPrice
        FROM @SaleItems;

        
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        
        ROLLBACK TRANSACTION;

        THROW;
    END CATCH
END;
  
  
  
  
  
  
  
  CREATE procedure [dbo].[GetReportDataProc]
     @CustomerId INT
  AS
  BEGIN
  SELECT S.Id, S.SaleDate, P.Name ProductName, P.Price, I.TotalPrice, I.Quantity, C.NAME CustomerName, c.Email, c.Phone, C.Address FROM  SaleItem I
  JOIN SALE S ON I.SaleId = S.Id
  JOIN PRODUCT P ON P.Id = I.ProductId
  JOIN CUSTOMER C ON C.ID = S.CustomerId
  WHERE C.Id = @CustomerId
  END



  CREATE PROCEDURE [dbo].[AddProductProc]
    @Name NVARCHAR(100),
    @Price DECIMAL(18, 2),
    @NewId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
	INSERT INTO Product (Name, Price)
        VALUES (@Name, @Price);
    SET @NewId = SCOPE_IDENTITY();
END;


CREATE Procedure [dbo].[GetAllSaleWithCustomer]
AS
BEGIN
Select c.Id, C.Name, C.Email, C.Phone, S.SaleDate, SUM(I.Quantity) Quantity, SUM(I.TotalPrice) TotalPrice From 
  Customer C 
  join Sale S on c.Id = s.CustomerId
  Join SaleItem I on s.Id = I.SaleId
  Group By c.Id, C.Name, C.Email, C.Phone, S.SaleDate
  Order By c.Id DESC
END;




CREATE Procedure [dbo].[GetAllSaleWithCustomerById]
@Id INT
AS
BEGIN
 Select c.Id, C.Name, C.Email, C.Phone, S.SaleDate, SUM(I.Quantity) Quantity, SUM(I.TotalPrice) TotalPrice From 
  Customer C 
  join Sale S on c.Id = s.CustomerId
  Join SaleItem I on s.Id = I.SaleId
  Where C.Id = @Id
  Group By c.Id, C.Name, C.Email, C.Phone, S.SaleDate 
  Order By c.Id DESC
END;




CREATE Procedure [dbo].[GetASalesWithCustomerByCustomerId]
@Id INT
AS
BEGIN
 Select c.Id, C.Name, C.Email, C.Phone, S.SaleDate, SUM(I.Quantity) Quantity, SUM(I.TotalPrice) TotalPrice From 
  Customer C 
  join Sale S on c.Id = s.CustomerId
  Join SaleItem I on s.Id = I.SaleId
  Where C.Id = @Id
  Group By c.Id, C.Name, C.Email, C.Phone, S.SaleDate 
  Order By c.Id DESC
END;






Create Procedure [dbo].[GetASalesWithCustomerByCustomerUserName]
@Name NVARCHAR(200)
AS
BEGIN
 Select c.Id, C.Name, C.Email, C.Phone, S.SaleDate, SUM(I.Quantity) Quantity, SUM(I.TotalPrice) TotalPrice From 
  Customer C 
  join Sale S on c.Id = s.CustomerId
  Join SaleItem I on s.Id = I.SaleId
  Where C.Name LIKE '%' + @Name + '%'
  Group By c.Id, C.Name, C.Email, C.Phone, S.SaleDate 
  Order By c.Id DESC
END;




Create Procedure [dbo].[GetCustomersProc]
as
Begin
Select * from Customer
order by Id Desc
END






CREATE PROCEDURE [dbo].[GetProductByIdProc]
@Id INT
as
BEGIN
SELECT * FROM PRODUCT WHERE Id = @Id;
END;



CREATE PROCEDURE [dbo].[GetProductsProc]
as
BEGIN
SELECT * FROM PRODUCT;
END;


